from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Student

class StudentInline(admin.StackedInline):
    model = Student
    can_delete = False
    verbose_name_plural = 'Student'
    fk_name = 'user'

class CustomUserAdmin(UserAdmin):
    inlines = (StudentInline,)
    
    def get_inline_instances(self, request, obj=None):
        if not obj:
            return list()
        return super().get_inline_instances(request, obj)

admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)