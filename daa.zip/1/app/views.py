from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegisterForm, UserUpdateForm, StudentUpdateForm
from models import Student
def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            Student.objects.create(
                user=user,
                age=form.cleaned_data['age'],
                phone_number=form.cleaned_data['phone_number'],
                bio=form.cleaned_data['bio']
            )
            
            login(request, user)
            messages.success(request, f'Siz uchun hisob yaratildi!')
            return redirect('home')
    else:
        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'Xush kelibsiz, {username}!')
            return redirect('home')
        else:
            messages.error(request, 'Login yoki parol noto\'g\'ri.')
    return render(request, 'login.html')

@login_required
def user_logout(request):
    """Chiqish funksiyasi"""
    logout(request)
    messages.info(request, 'Siz tizimdan chiqdingiz.')
    return redirect('home')

@login_required
def profile(request):
    """Profilni ko'rsatish va yangilash funksiyasi"""
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        s_form = StudentUpdateForm(request.POST, instance=request.user.student)
        
        if u_form.is_valid() and s_form.is_valid():
            u_form.save()
            s_form.save()
            messages.success(request, 'Profil muvaffaqiyatli yangilandi!')
            return redirect('profile')
    else:
        u_form = UserUpdateForm(instance=request.user)
        s_form = StudentUpdateForm(instance=request.user.student)
    
    context = {
        'u_form': u_form,
        's_form': s_form
    }
    
    return render(request, 'profile.html', context)